/**
 * Download e Pesquisa YouTube usando API BronxysHost
 * Adaptado para usar api.bronxyshost.com.br
 */

import { apiClient } from '../../utils/httpClient.js';

// Função para buscar vídeos no YouTube via BronxysHost
async function search(query, apiKey) {
  try {
    if (!apiKey) throw new Error('API key não fornecida');

    const response = await apiClient.get(
      `https://api.bronxyshost.com.br/api-bronxys/pesquisa_ytb?nome=${encodeURIComponent(query)}&apikey=${apiKey}`
    );

    if (!response.data || !response.data[0]) {
      throw new Error('Resposta inválida da API Bronxys');
    }

    return {
      ok: true,
      criador: 'BronxysHost',
      data: response.data[0]
    };

  } catch (error) {
    console.error('Erro na busca YouTube (Bronxys):', error.message);
    return {
      ok: false,
      msg: 'Erro ao buscar vídeo: ' + error.message
    };
  }
}

// Função para baixar áudio (MP3) via BronxysHost
async function mp3(query, apiKey) {
  try {
    if (!apiKey) throw new Error('API key não fornecida');

    const url = `https://api.bronxyshost.com.br/api-bronxys/play?nome_url=${encodeURIComponent(query)}&apikey=${apiKey}`;

    return {
      ok: true,
      buffer: url, // Bronxys já retorna um link direto
      filename: `audio_${Date.now()}.mp3`,
      quality: `128kbps`
    };

  } catch (error) {
    console.error('Erro no download MP3 (Bronxys):', error.message);
    return {
      ok: false,
      msg: 'Erro ao baixar áudio: ' + error.message
    };
  }
}

// Função para baixar vídeo (MP4) via BronxysHost
async function mp4(query, apiKey) {
  try {
    if (!apiKey) throw new Error('API key não fornecida');

    const url = `https://api.bronxyshost.com.br/api-bronxys/play_video?nome_url=${encodeURIComponent(query)}&apikey=${apiKey}`;

    return {
      ok: true,
      buffer: url, // Bronxys já retorna um link direto
      filename: `video_${Date.now()}.mp4`,
      quality: `360p`
    };

  } catch (error) {
    console.error('Erro no download MP4 (Bronxys):', error.message);
    return {
      ok: false,
      msg: 'Erro ao baixar vídeo: ' + error.message
    };
  }
}

export {
  search,
  mp3,
  mp4
};

export const ytmp3 = mp3;
export const ytmp4 = mp4;